//To see how the final website should work, run "node solution.js".
//Make sure you have installed all the dependencies with "npm i".
//The password is ILoveProgramming

import express from "express";
import bodyParser from "body-parser";
// import morgan from "morgan";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = 3000;
let pswd='';

const __dirname = dirname(fileURLToPath(import.meta.url));

function passwordControl(req,res,next){
    console.log(req.body);
    pswd=req.body.password;
    if(pswd=='ILoveProgramming'){
        
    }
    else{
        console.log('no good password');
        // app.get('/',(req,res)=>{
        //     console.log(`Directory name is ${__dirname}`); 
        //     console.log(req.body);
        //     res.sendFile(__dirname + "/public/index.html");
        //   })
        res.sendFile(__dirname + "/public/index.html");
    }
    next()
}

// app.use(bodyParser.urlencoded({extended: true}));
app.use(express.urlencoded({extended: true}));
// // app.use(express.json());
app.use(passwordControl);

app.get('/',(req,res)=>{
  console.log(`Directory name is ${__dirname}`); 
  console.log(req.body);
  res.sendFile(__dirname + "/public/index.html");
})

app.post('/check',(req,res)=>{
  console.log(`${req.body.password}`)
  console.log('in check'+req.body);
//   res.send(`<h1>ok success</h1><h2>You band name is ${band}</h2>`)
  res.sendFile(__dirname + "/public/secret.html");

})

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});